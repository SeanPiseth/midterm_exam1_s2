import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LockerApplication extends JFrame implements ActionListener {
    private JTextField setPasswordField, verifyPasswordField;
    private JButton setPasswordButton, verifyPasswordButton;
    private String password = null;
    private boolean passwordSet = false;

    public LockerApplication() {
        setTitle("Locker Application");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the frame on the screen

        // Create components
        JPanel panel = new JPanel(new GridLayout(3, 2));

        JLabel setPasswordLabel = new JLabel("Set Password:");
        JLabel verifyPasswordLabel = new JLabel("Verify Password:");

        setPasswordField = new JTextField(10);
        verifyPasswordField = new JTextField(10);

        setPasswordButton = new JButton("Set Password");
        verifyPasswordButton = new JButton("Verify Password");

        // Add components to the panel
        panel.add(setPasswordLabel);
        panel.add(setPasswordField);
        panel.add(setPasswordButton);
        panel.add(verifyPasswordLabel);
        panel.add(verifyPasswordField);
        panel.add(verifyPasswordButton);

        // Add panel to the frame
        add(panel, BorderLayout.CENTER);

        // Register action listeners
        setPasswordButton.addActionListener(this);
        verifyPasswordButton.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == setPasswordButton) {
            String setPassword = setPasswordField.getText();
            if (setPassword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a password", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                password = setPassword;
                passwordSet = true;
                JOptionPane.showMessageDialog(this, "Password Set", "Success", JOptionPane.INFORMATION_MESSAGE);
                setPasswordField.setText("");
            }
        } else if (e.getSource() == verifyPasswordButton) {
            String verifyPassword = verifyPasswordField.getText();
            if (!passwordSet) {
                JOptionPane.showMessageDialog(this, "Password not set yet", "Error", JOptionPane.ERROR_MESSAGE);
            } else if (verifyPassword.equals(password)) {
                JOptionPane.showMessageDialog(this, "Correct Password", "Success", JOptionPane.INFORMATION_MESSAGE);
                verifyPasswordField.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect Password", "Error", JOptionPane.ERROR_MESSAGE);
                verifyPasswordField.setText("");
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LockerApplication lockerApp = new LockerApplication();
            lockerApp.setVisible(true);
        });
    }
}
